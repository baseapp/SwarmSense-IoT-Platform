# DEBUG = True
SECRET_KEY = "jhawue1273hqaws7a3erjka"
SQLALCHEMY_DATABASE_URI = 'postgresql://gopal:root@localhost:5432/godb'
SQLALCHEMY_ECHO = False
SQLALCHEMY_POOL_SIZE = 10

# Time Series Database
TSDB_CLIENT = 'influx'
TSDB_HOST = 'localhost'
TSDB_PORT = 8086
TSDB_USERNAME = 'root'
TSDB_PASSWORD = 'root'
TSDB_DB = 'snms'

SQLALCHEMY_TRACK_MODIFICATIONS = False


EMAIL_FILE_PATH = '/work/tmp/'

TIME_ZONE = 'UTC'

CELERY_TIMEZONE = TIME_ZONE
CELERY_BROKER_URL = 'redis://localhost:6379'
CELERY_RESULT_BACKEND = 'redis://localhost:6379'

EMAIL_BACKEND = 'smtp'
EMAIL_PORT = 1025

MQTT_BROKER_URL = 'test.mosquitto.org'
# Mail backends shipped with SNMS.
